<?php 

require_once 'Controller.php';
require_once 'model/EditorialModel.php';

class EditorialesController extends Controller{
    
    private $model;

    function __construct(){
        $this->model = new EditorialModel();
    }

    public function index(){
        $viewBag=[];

        $viewBag['editoriales'] = $this->model->get('');
        
        $this->render('index.php', $viewBag);
    }

    public function create(){
        $this->render('new.php');
    }

    public function insert() {
        $editorial['codigo_editorial'] = $_POST['codigo_editorial'];
        $editorial['nombre_editorial'] = $_POST['nombre_editorial'];
        $editorial['contacto'] = $_POST['contacto'];
        $editorial['telefono'] = $_POST['telefono'];
        print_r($editorial);
    }
}


?>