<?php 

class IndexController{

    public function index(){
        echo 'soy el index controller';
    }
}

?>